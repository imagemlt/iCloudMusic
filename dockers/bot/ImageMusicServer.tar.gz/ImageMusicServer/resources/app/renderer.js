// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.
var redis = require('redis');
var request = require('request');
var {remote} = require('electron')
var client = redis.createClient(6379, '172.16.233.111');

client.set('hello', 'This is a value');

function rpop() {
    client.rpop('MSGQ', function (err, v) {
        //  console.log("redis get hello err,v",err,v);
        if (v == null) {
            setTimeout(rpop, 1000);
        } else {
            let v2 = JSON.parse(v);
            console.log(v2);
            try {
                
                                try {
                                    let currentId = remote.getCurrentWebContents().id;
                                    let js_to_run = `
						                window.music_info={header:'${v2.music.header}',title:'${v2.music.title.substr(0, 10)}',desc:'${v2.music.desc.substr(0, 50)}'};
						                console.log(music_info);
	//					                window.pid=${v2.id};
	//					                window.fid=${currentId};
	//					                avator.src=music_info['header'];
	//					                avName.innerText=music_info['title'];
	//					                avDesp.innerText=music_info['desc'];
	//					                avator.onclick=play;
						                //refreshCode();
          				            `
                                    console.log(js_to_run)
                                    view.executeJavaScript(js_to_run);
                                } catch (e) {
                                    console.log(e);
                                }
                                setTimeout(() => {
                                    location.reload();
                                }, 1000)
                            
                        


                    
            } catch (e) {
                console.log(e);

            }

        }//process.exit()}
    })
}

rpop()
